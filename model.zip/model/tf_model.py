# import packages
import tensorflow as tf

# define a simple model
def build_model():
    inputs = tf.keras.Input(shape=(2,), name='inputs')
    x = tf.keras.layers.Dense(4, activation='relu', name='dense1')(inputs)
    outputs = tf.keras.layers.Dense(1, name='outputs')(x)
    model = tf.keras.Model(inputs=inputs, outputs=outputs)
    return model

# create an instance of the model and save it in SavedModel format
model = build_model()
model.save('saved_model')

# load the SavedModel
loaded_model = tf.saved_model.load('saved_model')

# create some test data
test_input = tf.constant([[0.5, 0.5], [0.2, 0.2]])

# call the model on the test data
result = loaded_model.signatures['serving_default'](inputs=test_input)
print(result)
